/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <stdbool.h>
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include "app_common.h"
#include "log_module.h"
#include "ble.h"
#include "app_ble.h"
#include "intelliwave.h"
#include "ecg_processing.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define ADS_FRAME_BYTES 9U
#define ADS_SPI_TIMEOUT_MS 2U
#define ADS_DRDY_TIMEOUT_MS 100U
#define UART_TX_TIMEOUT_MS 100U
#define UART_QUEUE_CAPACITY 32U
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

RAMCFG_HandleTypeDef hramcfg_SRAM1;

RNG_HandleTypeDef hrng;

RTC_HandleTypeDef hrtc;

SPI_HandleTypeDef hspi1;

TIM_HandleTypeDef htim17;

UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */
typedef struct {
    int32_t ch1;
    uint8_t leads_off;
} ECG_Output;

typedef struct {
    uint32_t frames;
    uint32_t spi_errors;
    uint32_t invalid_frames;
    uint32_t sample_gaps;
    uint32_t clipped_samples;
    uint32_t uart_dropped;
    uint32_t uart_errors;
    uint32_t uart_timeouts;
    uint32_t drdy_timeouts;
} ECG_Diagnostics;

volatile ECG_Diagnostics ecg_diagnostics;
volatile uint8_t uart_tx_busy = 0U;
volatile uint8_t ads_leads_off = 1U;
volatile uint8_t ads_loff_stat = 0U;

static ECG_Filter ecg_filter;
static ECG_Output uart_queue[UART_QUEUE_CAPACITY];
static uint8_t uart_queue_head;
static uint8_t uart_queue_tail;
static uint8_t uart_queue_count;
static uint8_t uart_tx_buf[64];
static uint32_t uart_tx_started;
static uint32_t ads_last_frame_tick;
static uint8_t ads_have_frame;
static uint8_t ads_consecutive_errors;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void PeriphCommonClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_TIM17_Init(void);
static void MX_SPI1_Init(void);
/* USER CODE BEGIN PFP */
void MX_ICACHE_Init(void);
void MX_RAMCFG_Init(void);
void MX_RNG_Init(void);
void MX_RTC_Init(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
#define ADS_CS_LOW() HAL_GPIO_WritePin(ADS_CS_GPIO_Port, ADS_CS_Pin, GPIO_PIN_RESET)
#define ADS_CS_HIGH() HAL_GPIO_WritePin(ADS_CS_GPIO_Port, ADS_CS_Pin, GPIO_PIN_SET)

static void ADS_CS_Hold(void)
{
    /* At least 10 us at the configured CPU clock; ADS clock assumed 512 kHz. */
    volatile uint32_t cycles = SystemCoreClock / 100000U + 1U;
    while (cycles != 0U) {
        __NOP();
        --cycles;
    }
}

static HAL_StatusTypeDef ADS_WriteCmd(uint8_t cmd)
{
    ADS_CS_LOW();
    __DSB();
    HAL_StatusTypeDef result = HAL_SPI_Transmit(&hspi1, &cmd, 1U, ADS_SPI_TIMEOUT_MS);
    HAL_Delay(1U);
    ADS_CS_HIGH();
    HAL_Delay(1U);
    return result;
}

static HAL_StatusTypeDef ADS_WriteReg(uint8_t reg, uint8_t value)
{
    uint8_t tx[3] = {(uint8_t)(0x40U | reg), 0U, value};
    HAL_StatusTypeDef result = HAL_OK;
    ADS_CS_LOW();
    __DSB();
    for (uint32_t i = 0U; i < sizeof(tx); ++i) {
        result = HAL_SPI_Transmit(&hspi1, &tx[i], 1U, ADS_SPI_TIMEOUT_MS);
        HAL_Delay(1U);
        if (result != HAL_OK) break;
    }
    ADS_CS_HIGH();
    HAL_Delay(1U);
    return result;
}

static HAL_StatusTypeDef ADS_ReadReg(uint8_t reg, uint8_t *value)
{
    uint8_t tx[3] = {(uint8_t)(0x20U | reg), 0U, 0U};
    uint8_t rx[3] = {0};
    HAL_StatusTypeDef result = HAL_OK;
    ADS_CS_LOW();
    __DSB();
    for (uint32_t i = 0U; i < sizeof(tx); ++i) {
        result = HAL_SPI_TransmitReceive(&hspi1, &tx[i], &rx[i], 1U,
                                         ADS_SPI_TIMEOUT_MS);
        HAL_Delay(1U);
        if (result != HAL_OK) break;
    }
    ADS_CS_HIGH();
    HAL_Delay(1U);
    if (result == HAL_OK) *value = rx[2];
    return result;
}

static HAL_StatusTypeDef ADS1292_Init(void)
{
    static const uint8_t registers[][2] = {
        {0x01U, ECG_CONFIG1_VALUE},
        {0x02U, 0xE0U},
        {0x03U, 0x10U},
        {0x04U, 0x60U},
        {0x05U, 0x81U},
        {0x06U, 0x20U},
        {0x07U, 0x03U},
        {0x0AU, 0x07U}
    };
    uint8_t value = 0U;
    HAL_GPIO_WritePin(ADS_START_GPIO_Port, ADS_START_Pin, GPIO_PIN_RESET);
    ADS_CS_HIGH();
    HAL_GPIO_WritePin(ADS_RESET_GPIO_Port, ADS_RESET_Pin, GPIO_PIN_SET);
    HAL_Delay(1000U);
    HAL_GPIO_WritePin(ADS_RESET_GPIO_Port, ADS_RESET_Pin, GPIO_PIN_RESET);
    HAL_Delay(1U);
    HAL_GPIO_WritePin(ADS_RESET_GPIO_Port, ADS_RESET_Pin, GPIO_PIN_SET);
    HAL_Delay(10U);

    if (ADS_WriteCmd(0x11U) != HAL_OK) return HAL_ERROR;
    if (ADS_ReadReg(0x00U, &value) != HAL_OK) return HAL_ERROR;
    if (value != 0x53U && value != 0x73U) return HAL_ERROR;

    for (uint32_t i = 0U; i < sizeof(registers) / sizeof(registers[0]); ++i) {
        if (ADS_WriteReg(registers[i][0], registers[i][1]) != HAL_OK)
            return HAL_ERROR;
        if (ADS_ReadReg(registers[i][0], &value) != HAL_OK ||
            value != registers[i][1]) return HAL_ERROR;
    }
    HAL_Delay(100U);
    if (ADS_WriteCmd(0x10U) != HAL_OK) return HAL_ERROR;
    HAL_GPIO_WritePin(ADS_START_GPIO_Port, ADS_START_Pin, GPIO_PIN_SET);
    ads_last_frame_tick = HAL_GetTick();
    return HAL_OK;
}

static void UART_QueueSample(int32_t ch1, uint8_t leads_off)
{
    if (uart_queue_count == UART_QUEUE_CAPACITY) {
        ++ecg_diagnostics.uart_dropped;
        return;
    }
    uart_queue[uart_queue_head].ch1 = ch1;
    uart_queue[uart_queue_head].leads_off = leads_off;
    uart_queue_head = (uint8_t)((uart_queue_head + 1U) % UART_QUEUE_CAPACITY);
    ++uart_queue_count;
}

static void UART_Process(void)
{
    if (uart_tx_busy) {
        if ((uint32_t)(HAL_GetTick() - uart_tx_started) < UART_TX_TIMEOUT_MS)
            return;
        if (HAL_UART_AbortTransmit(&huart1) != HAL_OK) Error_Handler();
        uart_tx_busy = 0U;
        ++ecg_diagnostics.uart_timeouts;
        ++ecg_diagnostics.uart_dropped;
    }
    if (uart_queue_count == 0U) return;

    const ECG_Output *sample = &uart_queue[uart_queue_tail];
    int len = snprintf((char *)uart_tx_buf, sizeof(uart_tx_buf),
                       "%ld,0,%u\r\n", (long)sample->ch1,
                       (unsigned)sample->leads_off);
    if (len <= 0 || (size_t)len >= sizeof(uart_tx_buf)) {
        ++ecg_diagnostics.uart_dropped;
    } else {
        uart_tx_started = HAL_GetTick();
        uart_tx_busy = 1U;
        if (HAL_UART_Transmit_IT(&huart1, uart_tx_buf, (uint16_t)len) != HAL_OK) {
            uart_tx_busy = 0U;
            ++ecg_diagnostics.uart_errors;
            return;
        }
    }
    uart_queue_tail = (uint8_t)((uart_queue_tail + 1U) % UART_QUEUE_CAPACITY);
    --uart_queue_count;
}

static void ADS_RecordError(void)
{
    ECG_Filter_Reset(&ecg_filter);
    ads_leads_off = 1U;
    if (++ads_consecutive_errors >= 3U) Error_Handler();
}

static void ADS_ReadSample(void)
{
    uint8_t tx[ADS_FRAME_BYTES] = {0};
    uint8_t rx[ADS_FRAME_BYTES] = {0};
    const uint32_t tick = HAL_GetTick();
    ADS_CS_LOW();
    __DSB();
    HAL_StatusTypeDef result = HAL_SPI_TransmitReceive(&hspi1, tx, rx,
                                    ADS_FRAME_BYTES, ADS_SPI_TIMEOUT_MS);
    ADS_CS_Hold();
    ADS_CS_HIGH();
    if (result != HAL_OK) {
        ++ecg_diagnostics.spi_errors;
        ADS_RecordError();
        return;
    }
    if ((rx[0] & 0xF0U) != 0xC0U || (rx[1] & 0x1FU) != 0U || rx[2] != 0U) {
        ++ecg_diagnostics.invalid_frames;
        ADS_RecordError();
        return;
    }
    if (ads_have_frame && (uint32_t)(tick - ads_last_frame_tick) >= 8U) {
        ++ecg_diagnostics.sample_gaps;
        ECG_Filter_Reset(&ecg_filter);
    }
    ads_have_frame = 1U;
    ads_last_frame_tick = tick;
    ads_consecutive_errors = 0U;
    ++ecg_diagnostics.frames;

    ads_loff_stat = ADS_DecodeLeadOff(rx);
    ads_leads_off = (ads_loff_stat & 0x03U) != 0U;
    const int32_t raw = ADS_Decode24(&rx[3]);
    int32_t filtered = 0;
    if (raw == 8388607 || raw == -8388608) {
        ++ecg_diagnostics.clipped_samples;
        ECG_Filter_Reset(&ecg_filter);
    } else if (ads_leads_off) {
        ECG_Filter_Reset(&ecg_filter);
    } else {
        filtered = ECG_Filter_Apply(&ecg_filter, raw);
    }
    UART_QueueSample(filtered, ads_leads_off);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();
  /* Config code for STM32_WPAN (HSE Tuning must be done before system clock configuration) */
  MX_APPE_Config();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* Configure the peripherals common clocks */
  PeriphCommonClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ICACHE_Init();
  MX_RAMCFG_Init();
  MX_RNG_Init();
  MX_RTC_Init();
  MX_USART1_UART_Init();
  MX_TIM17_Init();
  MX_SPI1_Init();
  /* USER CODE BEGIN 2 */
ECG_Filter_Init(&ecg_filter);
  if (ADS1292_Init() != HAL_OK) Error_Handler();
/* USER CODE END 2 */

  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
    /* USER CODE BEGIN 3 */
    if (HAL_GPIO_ReadPin(ADS_DRDY_GPIO_Port, ADS_DRDY_Pin) == GPIO_PIN_RESET)
        ADS_ReadSample();

    UART_Process();
    const uint32_t now = HAL_GetTick();
    if ((uint32_t)(now - ads_last_frame_tick) >= ADS_DRDY_TIMEOUT_MS) {
        ++ecg_diagnostics.drdy_timeouts;
        HAL_GPIO_WritePin(ADS_START_GPIO_Port, ADS_START_Pin, GPIO_PIN_RESET);
        Error_Handler();
    }
    static uint32_t last_led_tick;
    if ((uint32_t)(now - last_led_tick) >= 500U) {
        last_led_tick = now;
        HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_2);
    }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_MEDIUMLOW);

  /** Initializes the CPU, AHB and APB busses clocks
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_HSE
                              |RCC_OSCILLATORTYPE_LSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEDiv = RCC_HSE_DIV1;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL1.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB busses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_PCLK7|RCC_CLOCKTYPE_HCLK5;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSE;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB7CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.AHB5_PLL1_CLKDivider = RCC_SYSCLK_PLL1_DIV1;
  RCC_ClkInitStruct.AHB5_HSEHSI_CLKDivider = RCC_SYSCLK_HSEHSI_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }

   /* Select SysTick source clock */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_LSE);

   /* Re-Initialize Tick with new clock source */
  if (HAL_InitTick(TICK_INT_PRIORITY) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief Peripherals Common Clock Configuration
  * @retval None
  */
void PeriphCommonClock_Config(void)
{
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the peripherals clock
  */
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RADIOST;
  PeriphClkInit.RadioSlpTimClockSelection = RCC_RADIOSTCLKSOURCE_LSE;

  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ICACHE Initialization Function
  * @param None
  * @retval None
  */
void MX_ICACHE_Init(void)
{

  /* USER CODE BEGIN ICACHE_Init 0 */

  /* USER CODE END ICACHE_Init 0 */

  /* USER CODE BEGIN ICACHE_Init 1 */

  /* USER CODE END ICACHE_Init 1 */

  /** Enable instruction cache in 1-way (direct mapped cache)
  */
  if (HAL_ICACHE_ConfigAssociativityMode(ICACHE_1WAY) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_ICACHE_Enable() != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ICACHE_Init 2 */

  /* USER CODE END ICACHE_Init 2 */

}

/**
  * @brief RAMCFG Initialization Function
  * @param None
  * @retval None
  */
void MX_RAMCFG_Init(void)
{

  /* USER CODE BEGIN RAMCFG_Init 0 */

  /* USER CODE END RAMCFG_Init 0 */

  /* USER CODE BEGIN RAMCFG_Init 1 */

  /* USER CODE END RAMCFG_Init 1 */

  /** Initialize RAMCFG SRAM1
  */
  hramcfg_SRAM1.Instance = RAMCFG_SRAM1;
  if (HAL_RAMCFG_Init(&hramcfg_SRAM1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RAMCFG_Init 2 */

  /* USER CODE END RAMCFG_Init 2 */

}

/**
  * @brief RNG Initialization Function
  * @param None
  * @retval None
  */
void MX_RNG_Init(void)
{

  /* USER CODE BEGIN RNG_Init 0 */

  /* USER CODE END RNG_Init 0 */

  /* USER CODE BEGIN RNG_Init 1 */

  /* USER CODE END RNG_Init 1 */
  hrng.Instance = RNG;
  hrng.Init.ClockErrorDetection = RNG_CED_DISABLE;
  if (HAL_RNG_Init(&hrng) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RNG_Init 2 */

  /* USER CODE END RNG_Init 2 */

}

/**
  * @brief RTC Initialization Function
  * @param None
  * @retval None
  */
void MX_RTC_Init(void)
{

  /* USER CODE BEGIN RTC_Init 0 */

  /* USER CODE END RTC_Init 0 */

  RTC_PrivilegeStateTypeDef privilegeState = {0};
  RTC_AlarmTypeDef sAlarm = {0};

  /* USER CODE BEGIN RTC_Init 1 */

  /* USER CODE END RTC_Init 1 */

  /** Initialize RTC Only
  */
  hrtc.Instance = RTC;
  hrtc.Init.AsynchPrediv = 31;
  hrtc.Init.OutPut = RTC_OUTPUT_DISABLE;
  hrtc.Init.OutPutRemap = RTC_OUTPUT_REMAP_NONE;
  hrtc.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
  hrtc.Init.OutPutType = RTC_OUTPUT_TYPE_OPENDRAIN;
  hrtc.Init.OutPutPullUp = RTC_OUTPUT_PULLUP_NONE;
  hrtc.Init.BinMode = RTC_BINARY_ONLY;
  if (HAL_RTC_Init(&hrtc) != HAL_OK)
  {
    Error_Handler();
  }
  privilegeState.rtcPrivilegeFull = RTC_PRIVILEGE_FULL_NO;
  privilegeState.backupRegisterPrivZone = RTC_PRIVILEGE_BKUP_ZONE_NONE;
  privilegeState.backupRegisterStartZone2 = RTC_BKP_DR0;
  privilegeState.backupRegisterStartZone3 = RTC_BKP_DR0;
  if (HAL_RTCEx_PrivilegeModeSet(&hrtc, &privilegeState) != HAL_OK)
  {
    Error_Handler();
  }

  /* USER CODE BEGIN Check_RTC_BKUP */

  /* USER CODE END Check_RTC_BKUP */

  /** Initialize RTC and set the Time and Date
  */
  if (HAL_RTCEx_SetSSRU_IT(&hrtc) != HAL_OK)
  {
    Error_Handler();
  }

  /** Enable the Alarm A
  */
  sAlarm.BinaryAutoClr = RTC_ALARMSUBSECONDBIN_AUTOCLR_NO;
  sAlarm.AlarmTime.SubSeconds = 0x0;
  sAlarm.AlarmMask = RTC_ALARMMASK_NONE;
  sAlarm.AlarmSubSecondMask = RTC_ALARMSUBSECONDBINMASK_NONE;
  sAlarm.Alarm = RTC_ALARM_A;
  if (HAL_RTC_SetAlarm_IT(&hrtc, &sAlarm, RTC_FORMAT_BCD) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RTC_Init 2 */

  /* USER CODE END RTC_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  SPI_AutonomousModeConfTypeDef HAL_SPI_AutonomousMode_Cfg_Struct = {0};

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_2EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 0x7;
  hspi1.Init.NSSPMode = SPI_NSS_PULSE_DISABLE;
  hspi1.Init.NSSPolarity = SPI_NSS_POLARITY_LOW;
  hspi1.Init.FifoThreshold = SPI_FIFO_THRESHOLD_01DATA;
  hspi1.Init.MasterSSIdleness = SPI_MASTER_SS_IDLENESS_00CYCLE;
  hspi1.Init.MasterInterDataIdleness = SPI_MASTER_INTERDATA_IDLENESS_00CYCLE;
  hspi1.Init.MasterReceiverAutoSusp = SPI_MASTER_RX_AUTOSUSP_DISABLE;
  hspi1.Init.MasterKeepIOState = SPI_MASTER_KEEP_IO_STATE_DISABLE;
  hspi1.Init.IOSwap = SPI_IO_SWAP_DISABLE;
  hspi1.Init.ReadyMasterManagement = SPI_RDY_MASTER_MANAGEMENT_INTERNALLY;
  hspi1.Init.ReadyPolarity = SPI_RDY_POLARITY_HIGH;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_SPI_AutonomousMode_Cfg_Struct.TriggerState = SPI_AUTO_MODE_DISABLE;
  if (HAL_SPIEx_SetConfigAutonomousMode(&hspi1, &HAL_SPI_AutonomousMode_Cfg_Struct) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief TIM17 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM17_Init(void)
{

  /* USER CODE BEGIN TIM17_Init 0 */

  /* USER CODE END TIM17_Init 0 */

  /* USER CODE BEGIN TIM17_Init 1 */

  /* USER CODE END TIM17_Init 1 */
  htim17.Instance = TIM17;
  htim17.Init.Prescaler = 3199;
  htim17.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim17.Init.Period = 199;
  htim17.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim17.Init.RepetitionCounter = 0;
  htim17.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim17) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM17_Init 2 */

  /* USER CODE END TIM17_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 460800;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart1, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart1, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */
   HAL_NVIC_SetPriority(USART1_IRQn, 5, 0);
   HAL_NVIC_EnableIRQ(USART1_IRQn);
  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_SYSCFG_CLK_ENABLE();
  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(ADS_RESET_GPIO_Port, ADS_RESET_Pin, GPIO_PIN_RESET);
  HAL_GPIO_WritePin(ADS_CS_GPIO_Port, ADS_CS_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(ADS_START_GPIO_Port, ADS_START_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : PA2 ADS_RESET_Pin ADS_CS_Pin */
  GPIO_InitStruct.Pin = GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
  GPIO_InitStruct.Pin = ADS_RESET_Pin;
  HAL_GPIO_Init(ADS_RESET_GPIO_Port, &GPIO_InitStruct);
  GPIO_InitStruct.Pin = ADS_CS_Pin;
  HAL_GPIO_Init(ADS_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : ADS_DRDY_Pin */
  GPIO_InitStruct.Pin = ADS_DRDY_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(ADS_DRDY_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : ADS_START_Pin */
  GPIO_InitStruct.Pin = ADS_START_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(ADS_START_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1) uart_tx_busy = 0U;
}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    if (huart->Instance == USART1) ++ecg_diagnostics.uart_errors;
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
