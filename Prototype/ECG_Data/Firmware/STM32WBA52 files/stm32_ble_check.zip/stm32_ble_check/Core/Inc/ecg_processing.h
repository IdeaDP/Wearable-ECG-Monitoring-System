#ifndef ECG_PROCESSING_H
#define ECG_PROCESSING_H

#include <math.h>
#include <stdint.h>
#include <string.h>

#define ECG_SAMPLE_RATE_HZ 250U
#define ECG_CONFIG1_VALUE 0x01U
#define ECG_HPF_HZ 0.5f
#define ECG_LPF_HZ 40.0f
#ifndef ECG_NOTCH_HZ
#define ECG_NOTCH_HZ 0
#endif
#if ECG_NOTCH_HZ != 0 && ECG_NOTCH_HZ != 50 && ECG_NOTCH_HZ != 60
#error "ECG_NOTCH_HZ must be 0, 50, or 60"
#endif

typedef struct {
    float b0, b1, b2, a1, a2;
    float z1, z2;
} ECG_Biquad;

typedef struct {
    ECG_Biquad hp, lp, notch;
    int32_t origin;
    uint8_t primed;
} ECG_Filter;

static inline void ECG_Biquad_Init(ECG_Biquad *s, float hz, unsigned type)
{
    const float w = 6.283185307179586f * hz / (float)ECG_SAMPLE_RATE_HZ;
    const float c = cosf(w);
    const float alpha = sinf(w) / (type == 2U ? 60.0f : 1.4142135623730951f);
    const float inv_a0 = 1.0f / (1.0f + alpha);
    memset(s, 0, sizeof(*s));
    if (type == 0U) {
        s->b0 = (1.0f + c) * 0.5f * inv_a0;
        s->b1 = -(1.0f + c) * inv_a0;
        s->b2 = s->b0;
    } else if (type == 1U) {
        s->b0 = (1.0f - c) * 0.5f * inv_a0;
        s->b1 = (1.0f - c) * inv_a0;
        s->b2 = s->b0;
    } else {
        s->b0 = inv_a0;
        s->b1 = -2.0f * c * inv_a0;
        s->b2 = inv_a0;
    }
    s->a1 = -2.0f * c * inv_a0;
    s->a2 = (1.0f - alpha) * inv_a0;
}

static inline void ECG_Filter_Init(ECG_Filter *f)
{
    memset(f, 0, sizeof(*f));
    ECG_Biquad_Init(&f->hp, ECG_HPF_HZ, 0U);
    ECG_Biquad_Init(&f->lp, ECG_LPF_HZ, 1U);
#if ECG_NOTCH_HZ != 0
    ECG_Biquad_Init(&f->notch, (float)ECG_NOTCH_HZ, 2U);
#endif
}

static inline void ECG_Filter_Reset(ECG_Filter *f)
{
    f->hp.z1 = f->hp.z2 = 0.0f;
    f->lp.z1 = f->lp.z2 = 0.0f;
    f->notch.z1 = f->notch.z2 = 0.0f;
    f->primed = 0U;
}

static inline float ECG_Biquad_Apply(ECG_Biquad *s, float x)
{
    const float y = s->b0 * x + s->z1;
    s->z1 = s->b1 * x - s->a1 * y + s->z2;
    s->z2 = s->b2 * x - s->a2 * y;
    return y;
}

static inline int32_t ECG_Filter_Apply(ECG_Filter *f, int32_t raw)
{
    if (!f->primed) {
        f->origin = raw;
        f->primed = 1U;
    }
    float y = (float)(raw - f->origin) / 8388608.0f;
    y = ECG_Biquad_Apply(&f->hp, y);
    y = ECG_Biquad_Apply(&f->lp, y);
#if ECG_NOTCH_HZ != 0
    y = ECG_Biquad_Apply(&f->notch, y);
#endif
    if (!isfinite(y)) {
        ECG_Filter_Reset(f);
        return 0;
    }
    y *= 8388608.0f;
    if (y >= 8388607.0f) return 8388607;
    if (y <= -8388608.0f) return -8388608;
    return (int32_t)(y + (y >= 0.0f ? 0.5f : -0.5f));
}

static inline int32_t ADS_Decode24(const uint8_t *p)
{
    const uint32_t u = ((uint32_t)p[0] << 16) |
                       ((uint32_t)p[1] << 8) | (uint32_t)p[2];
    return (u & 0x800000U) ? (int32_t)u - 16777216 : (int32_t)u;
}

static inline uint8_t ADS_DecodeLeadOff(const uint8_t *p)
{
    const uint32_t status = ((uint32_t)p[0] << 16) |
                           ((uint32_t)p[1] << 8) | (uint32_t)p[2];
    return (uint8_t)((status >> 15) & 0x1FU);
}

#endif
