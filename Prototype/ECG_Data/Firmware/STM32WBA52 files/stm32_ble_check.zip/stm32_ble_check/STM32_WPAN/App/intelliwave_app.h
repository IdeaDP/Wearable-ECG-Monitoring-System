/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    IntelliWave_app.h
  * @author  MCD Application Team
  * @brief   Header for IntelliWave_app.c
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef INTELLIWAVE_APP_H
#define INTELLIWAVE_APP_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
typedef enum
{
  INTELLIWAVE_CONN_HANDLE_EVT,
  INTELLIWAVE_DISCON_HANDLE_EVT,

  /* USER CODE BEGIN Service1_OpcodeNotificationEvt_t */

  /* USER CODE END Service1_OpcodeNotificationEvt_t */

  INTELLIWAVE_LAST_EVT,
} INTELLIWAVE_APP_OpcodeNotificationEvt_t;

typedef struct
{
  INTELLIWAVE_APP_OpcodeNotificationEvt_t          EvtOpcode;
  uint16_t                                 ConnectionHandle;

  /* USER CODE BEGIN INTELLIWAVE_APP_ConnHandleNotEvt_t */

  /* USER CODE END INTELLIWAVE_APP_ConnHandleNotEvt_t */
} INTELLIWAVE_APP_ConnHandleNotEvt_t;
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* External variables --------------------------------------------------------*/
/* USER CODE BEGIN EV */

/* USER CODE END EV */

/* Exported macros -----------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void INTELLIWAVE_APP_Init(void);
void INTELLIWAVE_APP_EvtRx(INTELLIWAVE_APP_ConnHandleNotEvt_t *p_Notification);
/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

#ifdef __cplusplus
}
#endif

#endif /*INTELLIWAVE_APP_H */
